package model;

public enum DriverTask {
     PICKUP,
     DROPOFF
}
