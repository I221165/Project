package model;

public enum ParcelHolder {
   DRIVER,
   CENTER,
   CUSTOMER
}
