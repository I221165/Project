package model;

public interface PaymentStrategy {
     void recordPayment(Payments p);
}
