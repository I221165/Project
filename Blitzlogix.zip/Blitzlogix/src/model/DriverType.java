package model;

public enum DriverType {
    InterCity,
    IntraCity
}
