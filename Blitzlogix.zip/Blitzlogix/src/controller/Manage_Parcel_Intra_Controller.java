package controller;



public class Manage_Parcel_Intra_Controller 
{
	
}
