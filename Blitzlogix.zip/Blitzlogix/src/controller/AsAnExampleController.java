package controller;

import javafx.fxml.FXML;

public class AsAnExampleController {

}
