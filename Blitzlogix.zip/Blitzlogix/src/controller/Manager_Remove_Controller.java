package controller;



public class Manager_Remove_Controller 
{
	
}
